package com.example.tp_21993992;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import java.util.Random;

public class Taupiniere extends ConstraintLayout {

    private ImageView taupe;
    private int taupeWidth, taupeHeight, taupeX , taupeY;
    private int l ;
    private int tour = 10 ;
    private TextView scoreView;
    private TextView partieView;
    private final int margin = 10 ;
    private long start , end ;
    private long score, bestScore ;

    public Taupiniere(@NonNull Context context ) {
        super(context);
        setWillNotDraw(false);

        scoreView = new TextView(context);
        scoreView.setId(View.generateViewId());
        scoreView.setBackgroundColor(Color.WHITE);
        scoreView.setText("Score : 0");
        scoreView.setTextSize(24);

        partieView= new TextView(context);
        partieView.setId(View.generateViewId());
        partieView.setBackgroundColor(Color.WHITE);
        partieView.setText("");
        partieView.setTextSize(24);

        taupe = new ImageView(context);
        taupe.setId(View.generateViewId());
        taupe.setImageResource(R.drawable.taupe);

        this.addView(taupe); this.addView(scoreView); this.addView(partieView);
        this.setBackgroundResource(R.drawable.taupiniere);

        DisplayMetrics dm = getResources( ).getDisplayMetrics( ) ;
        l = ( int ) TypedValue.applyDimension ( TypedValue.COMPLEX_UNIT_DIP, 100 , dm ) ;
        taupe.setLayoutParams (new LayoutParams ( l , l ) ) ;

        ConstraintSet constraintSet=new ConstraintSet();
        constraintSet.clone(this);
        constraintSet.connect(scoreView.getId(),ConstraintSet.LEFT,this.getId(),ConstraintSet.LEFT,margin);
        constraintSet.connect(scoreView.getId(),ConstraintSet.TOP,this.getId(),ConstraintSet.TOP,margin);

        constraintSet.connect(partieView.getId(),ConstraintSet.LEFT,scoreView.getId(),ConstraintSet.LEFT,margin*15);
        constraintSet.connect(partieView.getId(),ConstraintSet.TOP,this.getId(),ConstraintSet.TOP,margin);
        constraintSet.applyTo(this);

           }

    @Override
    protected void onDraw(Canvas canvas) {
      start = SystemClock.uptimeMillis();
      Random r = new Random() ;
      int randomX = r.nextInt(this.getWidth() - 200) ; // largeur - 1
      int randomY = r.nextInt(this.getHeight() - 200) ; // hauteur - 1
        taupe.setX((float) randomX +100) ;
        taupe.setY((float) randomY + 100) ;

        }

    @Override
    public boolean onTouchEvent (MotionEvent m) {
        super.onTouchEvent ( m );
        end = SystemClock.uptimeMillis();
        int x = (int) taupe.getX();
        int y = (int) taupe.getY();
        int mx = (int) m.getX();
        int my = (int) m.getY();
       /*
       Debug position.
         System.out.println(mx+" "+ my + " "+ l);
         System.out.println(x +" "+ y);
       */
        if (m.getAction()==MotionEvent.ACTION_DOWN)
        { tour--;
          if (mx >= x && mx <= x+l   &&  my > y && my <= y+l ) {
              if (end - start < 1000) { score += 1000 - (end - start) ;} else {score += 0;}
               scoreView.setText("Score : "+ score);
              checkScore();
               invalidate();
               return true;
          }
          }
        checkScore();
        return true;
    }


     private void checkScore () {
         if (tour == 0) {
             tour = 10 ;
             if (bestScore < score ) bestScore = score ;
             score= 0;
             partieView.setText("Best Score :" + bestScore);
             scoreView.setText(" Score :" + score);
             Toast.makeText(this.getContext() , "Nouvelle partie" , 10).show();
     }
}

}
